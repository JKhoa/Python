n = (input("Nhập chuỗi: "))[:2]
a=int(input("Nhập số lần lặp: "))
print(str(n)*a)