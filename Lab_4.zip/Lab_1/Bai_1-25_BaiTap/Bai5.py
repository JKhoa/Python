fname = input("Input first name: ")

lname = input("Input last name: ")

print ("Hello "+lname+" "+fname)