exam_st_date = (1, 1, 2025)
print("The examination will start from : %i / %i / %i" % exam_st_date)