import calendar 
y =int(input("Nhập năm: "))
m =int(input("Nhập tháng: "))
print(calendar.month(y,m))  