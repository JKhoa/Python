print(len.__doc__)
print(abs.__doc__)