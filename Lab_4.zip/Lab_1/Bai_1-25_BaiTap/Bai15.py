pi = 3.14
r=6.0
V = 4.0/3.0 * pi * r**3
print('Khối lượng hình cầu là: ', V)