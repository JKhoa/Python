a= int(input("Nhập n: "))

mod = a %2 
if mod >0:
    print("Đây là số lẻ")
else:
    print("Đây là số chẳn")