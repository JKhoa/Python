import sys
print("Python version")
print(sys.version)
print(sys.version_info)