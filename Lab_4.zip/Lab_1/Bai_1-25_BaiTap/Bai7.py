fn=input("Nhập filename: ")
f_e = fn.split(".")
print ("extension của filename là: "+repr(f_e[-1]))