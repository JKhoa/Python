def tim_chu(arr):
    a= 'abcxyz'
    return arr in a
print(tim_chu('c'))  
print(tim_chu('e'))  