from datetime import datetime

now = datetime.now()    

print ("Thời gian hiện tại: "+ now.strftime("%Y-%m-%d %H:%M:%S") )