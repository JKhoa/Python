from math import pi
r=(float(input("Nhập r: "))) 
area = pi *r ** 2
print(" The area of the circle "+str(r)+" is "+str(area))
