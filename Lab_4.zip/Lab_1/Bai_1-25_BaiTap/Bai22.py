def list_count_4(nums):
  count = 0
  for num in nums:
    if num == 4:
      count = count + 1
  return count
print(list_count_4([1, 4, 6, 7, 4]))  # Output: 2 (There are two occurrences of 4 in the list.)
print(list_count_4([1, 4, 6, 4, 7, 4]))  # Output: 3 (There are three occurrences of 4 in the list.)