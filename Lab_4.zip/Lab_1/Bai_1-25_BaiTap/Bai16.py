
def difference(n):
 
    if n <= 17:
    
        return 17 - n
    else:

        return (n - 17) * 2

print(difference(22))

print(difference(14))